package com.example.trabajomvvm.model

data class QuoteModel(val quote:String , val autor:String)
