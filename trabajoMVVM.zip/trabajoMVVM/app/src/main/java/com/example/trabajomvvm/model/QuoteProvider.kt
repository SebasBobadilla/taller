package com.example.trabajomvvm.model

class QuoteProvider {
    companion object {
        fun random(): QuoteModel {
            val position:Int = (0..10).random()
            return quote[position]
        }
        private val quote = listOf<QuoteModel>(
            QuoteModel(
                quote = "It’s not a bug. It’s an undocumented feature!",
                autor = "Anonymous"
            ),
            QuoteModel(
                quote = "“Software Developer” – An organism that turns caffeine into software",
                autor = "Anonymous"
            ),
            QuoteModel(
                quote = "If debugging is the process of removing software bugs, then programming must be the process of putting them in",
                autor = "Edsger Dijkstra"
            ),
            QuoteModel(
                quote = "A user interface is like a joke. If you have to explain it, it’s not that good.",
                autor = "Anonymous"
            ),
            QuoteModel(
                quote = "I don’t care if it works on your machine! We are not shipping your machine!",
                autor = "Vidiu Platon"
            ),
            QuoteModel(
                quote = "Measuring programming progress by lines of code is like measuring aircraft building progress by weight.",
                autor = "Bill Gates"
            ),
            QuoteModel(
                quote = "My code DOESN’T work, I have no idea why. My code WORKS, I have no idea why.",
                autor = "Anonymous"
            )
        )
    }
}